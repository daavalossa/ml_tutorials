# NLP Tutorials

Al igual que en el directorio de ML, para poder ejecutar los Notebooks te recomiendo crear tu propio entorno virtual único para estos ejercicios (por ejemplo con conda):

```conda create -n NOMBRE_ENTORNO python==3.10```

Luego, puedes instalar todas las librerías del `requirements.txt` con 
```pip install -r requirements.txt``` estando dentro del directorio de NLP (`cd NLP`). 

